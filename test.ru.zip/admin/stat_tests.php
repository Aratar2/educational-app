<?php
  header("Content-Type: text/html; charset=utf-8");
require_once "auth_validation.php";
?>
<html>
<head>
<title>Статистика по тестам</title>
   

<link rel="shortcut icon" href="stylesheet/img/devil-icon.png"> <!--Pemanggilan gambar favicon-->
<link rel="stylesheet" type="text/css" href="/css/style.css"> <!--pemanggilan file css-->
</head>

<body>
<div id="header">
	<div class="inHeader">
		<div class="mosAdmin">
        Администратор<br>
		<a href="config.php">Настройки</a> | <a href="logout.php">Выйти</a>
		</div>
	<div class="clear"></div>
	</div>
</div>

<div id="wrapper">
	<div id="leftBar">
	<ul>
		<li><a href="add_theory.php">Добавить тему</a></li>
		<li><a href="all_theory.php">Добавленные темы</a></li>
		<li><a href="tests.php">Тесты</a></li>
		<li><a href="stat_tests.php">Статистика по тестам</a></li>
	</ul>
	</div>
	<div id="rightContent">
	<h3>Статистика по тестам</h3>
	
	
	<?php


require_once $_SERVER['DOCUMENT_ROOT']."/db_config.php";
  
 
 
   ////Удаление записи
  if (isset($_REQUEST['delete']))
  {
  $id=$_REQUEST['delete'];
 $result=mysql_query("DELETE FROM `tests_result` WHERE `id`='$id'")or die(mysql_error());
  }
   ////Удаление записи
 
  
  
  
  


 
$result = mysql_query("SELECT *FROM tests_result ORDER BY `id`") or die(mysql_error());
echo "<br>";
	echo "<table>";
	echo "<tr class=\"data\">";

	//////////
	echo "<th class=\"data\" align=\"center\" >";
	echo "№";
	echo "</th>";
	//////////
	echo "<th class=\"data\" align=\"center\" >";
	echo "Код теста";
	echo "</th>";
	//////////
	echo "<th class=\"data\"  align=\"center\" >";
	echo "Логин";
	echo "</th>";
	//////////
	echo "<th class=\"data\"  align=\"center\" >";
	echo "Имя";
	echo "</th>";
	//////////
	echo "<th class=\"data\" align=\"center\" >";
	echo "Группа";
	echo "</th>";
	///////////
	echo "<th class=\"data\" align=\"center\" >";
	echo "Результат";
	echo "</th>";
	///////////
	echo "<th class=\"data\" align=\"center\" >";
	echo "Дата";
	echo "</th>";
	///////////
	echo "<th class=\"data\" align=\"center\" >";
	echo "";
	echo "</th>";
	///////////

	$i=1;
	echo "</tr>";
	while ($row = mysql_fetch_array($result)) {


		echo "<tr class=\"data\">";

		echo "<td class=\"data\" align=\"center\">";
		echo $i;
		echo "</td>";

		echo "<td class=\"data\" align=\"center\">";
		echo $row["kod_test"];
		echo "</td>";
		
		echo "<td class=\"data\" align=\"center\">";
		echo $row["login"];
		echo "</td>";


		echo "<td  class=\"data\" align=\"center\">";
		echo "<div id=\"width_td\">";
		echo $row["fullname"];
		echo "</div>";
		echo "</td>";


		echo "<td class=\"data\" align=\"center\">";
		echo $row["groups"];
		echo "</td>";

		echo "<td class=\"data\" align=\"center\">";
		echo $row["result"];
		echo "</td>";

		echo "<td class=\"data\" align=\"center\">";

		$dt_elements = explode(' ',$row["created_at"]);
		$date_elements = explode('-',$dt_elements[0]);
		$time_elements =  explode(':',$dt_elements[1]);
		echo $date_elements[2]."-".$date_elements[1]."-".$date_elements[0];
		echo "<br>";
		echo $time_elements[0].":".$time_elements[1].":".$time_elements[2];


		echo "</td>";


		echo "<td class=\"data\"  align=\"center\">";



		echo "<form class=\"form_style\"   action= \"test_result_prev.php\" method= \"POST\">";
		echo "<input type= \"hidden\" name= \"name_student\" value='".$row["fullname"]."''>";
		echo "<button class=\"button\" title=\"Просмотр\" type= \"submit\" name=prev value=".$row["id"]."><img src=\"/css/img/prev.png\" width=\"20px\" ></button>";
		echo "</form>";






		echo "<form class=\"form_style\" action= \"\" method= \"POST\">";

		echo "<button class=\"button\" title=\"Удалить\" type= \"submit\" name=delete value=".$row["id"]."><img src=\"/css/img/delete.png\" width=\"20px\" ></button>";
		echo "</form>";

		echo "</td>";


		echo "</tr>";
		$i=$i+1;
	}


	echo "</table>";

?>

	</div>
<div class="clear"></div>
<div id="footer">
	&copy; 2016
</div>
</div>
</body>
</html>